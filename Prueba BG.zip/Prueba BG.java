import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Parabank {
    public static void main(String[] args) {
        // Configurar la ruta del ChromeDriver donde se lo tiene alojado
        System.setProperty("webdriver.chrome.driver", "ruta/al/chromedriver");

        // Crear una instancia de WebDriver
        WebDriver driver = new ChromeDriver();

        // Colocar la página de a probar, en este caso Parabank
        driver.get("https://parabank.parasoft.com/parabank/index.htm");

        // Registrar un nuevo usuario
        registrar(driver);

        // ingresar al sistema
        login(driver);

        // no me permitia realizar un retiro debido a que al abrir esta opcion no me cargaba la pestaña y me aparecia en formato xml
		//buscando en el codigo interno de la pagina pude identificar los campos para crear el escenario a probar cuando se solucione
        retiro(driver);

        // Transferir dinero entre dos cuentas
        transferencia(driver);

        // Cerrar el navegador
        driver.quit();
    }

    public static void registrar(WebDriver driver) {
        driver.findElement(By.linkText("Register")).click();
        driver.findElement(By.id("customer.firstName")).sendKeys("jose");
        driver.findElement(By.id("customer.lastName")).sendKeys("aviles");
        driver.findElement(By.id("customer.address.street")).sendKeys("urdesa");
        driver.findElement(By.id("customer.address.city")).sendKeys("guayaquil");
        driver.findElement(By.id("customer.address.state")).sendKeys("guayas");
        driver.findElement(By.id("customer.address.zipCode")).sendKeys("090502");
        driver.findElement(By.id("customer.phoneNumber")).sendKeys("0982093358");
        driver.findElement(By.id("customer.ssn")).sendKeys("");
        driver.findElement(By.id("customer.username")).sendKeys("javiles");
        driver.findElement(By.id("customer.password")).sendKeys("094447253");
        driver.findElement(By.id("repeatedPassword")).sendKeys("094447253");
        driver.findElement(By.xpath("//input[@value='Register']")).click();
    }

    public static void login(WebDriver driver) {
        driver.findElement(By.name("username")).sendKeys("javiles");
        driver.findElement(By.name("password")).sendKeys("094447253");
        driver.findElement(By.xpath("//input[@value='Log In']")).click();
    }

    //public static void retiro(WebDriver driver) {
     //   driver.findElement(By.linkText("Withdraw Funds")).click();
     //   driver.findElement(By.id("amount")).sendKeys("50");
     //   driver.findElement(By.xpath("//input[@value='Withdraw']")).click();
    //}

    public static void transferencia(WebDriver driver) {
        driver.findElement(By.linkText("Transfer Funds")).click();
        driver.findElement(By.id("amount")).sendKeys("100");
        driver.findElement(By.id("fromAccountId")).sendKeys("13899");
        driver.findElement(By.id("toAccountId")).sendKeys("13899");
        driver.findElement(By.xpath("//input[@value='Transfer']")).click();
    }
}
